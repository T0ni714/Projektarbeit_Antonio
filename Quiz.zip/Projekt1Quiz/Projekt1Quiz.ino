//=================================== BIBLIOTHEKEN =========================================================
#include <TFT_eSPI.h>
#include <XPT2046_Touchscreen.h>
#include <SD.h> 
#include <SPI.h>
#include <ArduinoJson.h>
//----------- Font größen (mit fontconvert erstellt) ----------------
#include <Arial10pt8b.h>
#include <Arial14pt8b.h>
#include <Arial18pt8b.h>

// ================== SD-KARTE =============================================================================
#define SD_CS    8
#define SD_MOSI  3
#define SD_MISO  14
#define SD_SCLK  21

// ================= TFT & TOUCH ===========================================================================
// TFT über HSPI (wegen USE_HSPI_PORT)
TFT_eSPI tft = TFT_eSPI();

// Touch
SPIClass tsSPI = SPIClass(FSPI);
XPT2046_Touchscreen ts(TOUCH_CS, TOUCH_IRQ);


// =============Sd Karte Bus================================================================================
SPIClass sdSPI(HSPI);
//==============SD Initialiseiren===========================================================================
void initSD() {
  sdSPI.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);

  if (!SD.begin(SD_CS, sdSPI)) {
    Serial.println("SD-Karte FEHLER");
    while (1);
  }

  Serial.println("SD-Karte OK");
}
// ================= STATES ================================================================================
enum QuizState {
  STATE_MENU,          // Hauptmenü
  STATE_START,         // "Spiel beginnt"
  STATE_QUESTION,      // Frage anzeigen
  STATE_ANSWER_SELECT, // Nutzer tippt Antwort -> Auswahl wird Verarbeitet
  STATE_ANSWER_RESULT, // Ergebnis anzeigen -> gruen oder Rot
  STATE_GAMEOVER       // Spielende -> Punkteanzahl mit Zurück button
};

//=============== Auktueller und voheriger Zustand =========================================================
QuizState quizState = STATE_MENU;
QuizState lastState = STATE_GAMEOVER;

// ================= JSON ==================================================================================
DynamicJsonDocument doc(8192);

int* frageIndex = nullptr;
int anzahlFragen = 0;
int aktuelleFrage = 0;
int richtigeAnzahl = 0;

int gewaehlteAntwort = -1;  // Index der gewählten Antwort (0=A, 1=B, 2=C, 3=D), -1 = keine Auswahl
int richtigeAntwort = -1;
//================= TIMER ==================================================================================
unsigned long stateTimer = 0;
// ================= FARBEN ================================================================================
#define COLOR_YELLOW 0xFFE0 // GELB - für die angeklickte Antwort (vor der Auflösung)
#define COLOR_GREEN  0x07E0 // GRUEN - für richtige Antwort
#define COLOR_RED    0xF800 // ROT - für falsche Antwort
#define COLOR_BG   0x00CF // Navy blue (Hintergrund für alle Bildschirme) 

//======================= SETUP ============================================================================
void setup() {
  Serial.begin(115200);
  // Zufalls Generator initialisieren
  randomSeed(analogRead(A0)); // A0 muss unbeschaltet sein (ein zufälliger Pin der nicht benutzt wird)
  // ------------------ TFT Initialisierung ------------------
  Serial.println("Starte ILI9488...");
  tft.init();
  Serial.println("ILI init");
  tft.setRotation(1);
  // ------------------ Backlight  ON ------------------
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);
  // ------------------ Touch  Initialisierung ------------------
  Serial.println("Starte Touch...");
  // Wichtig: Wir initialisieren den Bus explizit mit den Pins aus der User_Setup.h
  tsSPI.begin(12, 13, 11, 10);
  ts.begin(tsSPI);
  Serial.println("TOUCH init");
  ts.setRotation(1);
  delay(250);
  Serial.println("Starte Sd Karte...");
  initSD(); // Funktion aufrufen

  ladeJSON(); // Funktion aufrufen
  mischeFragen(); // Funktion aufrufen
}

// ================= JSON ===================================================================================
void ladeJSON() {
  File f = SD.open("/DigitalTechnik.json");
  if (!f) {
    Serial.println("JSON Datei nicht gefunden !");
    while (1); // Programm anhalten -> ohne Fragen ist das Quiz nicht spielbar
  }
  // JSON-Inhalt aus der Datei in das Dokument einlesen
  deserializeJson(doc, f);
  f.close();

  anzahlFragen = doc["fragen"].size(); // Anzahl der Insgesamten Fragen ( 20 Fragen in unserem Fall)
  frageIndex = new int[anzahlFragen]; // Array reservieren mit 20 Plätze 
  // oben reserviere Array mit austeigenden Werten befüllen: (frageIndex[0] = 0, frageIndex[1] = 1, ... bis frageIndex[19] = 19 )
  // Diese Werte werden später beim Shufflen vertauscht
  for (int i = 0; i < anzahlFragen; i++)
    frageIndex[i] = i; // jeden Platzhalter einen Wert erteilen, (0 - 19)
}
//===============FRAGEN SCHUFFLEN============================================================================
//--------------- FISHER YATES SHUFFLE ( von hinten nach vorne) -------------------------
void mischeFragen() {
  for (int i = anzahlFragen - 1; i > 0; i--) { // Start wert 19(letzter Index ) endwert 1(vorletzer index) schritt weite -1, letzer Index kann nicht geshuffled werden weil man min. 2 indexe braucht
    int j = random(i + 1); // Züfalliger Wert zwischen 0 und i (20 im ersten durchlauf) z.B. 12
    // Variablen Tausch
    int tmp = frageIndex[i]; // der wert im Index 19 (Wert = 19) wird in einer temporären variablen gespeichert
    frageIndex[i] = frageIndex[j]; // der wert im zufalls Index 12 wird in den Index 19 gespeichert
    frageIndex[j] = tmp; // der wert der vorher im index 19 war, der jetzt in der temporär variable gespeichert ist, wird jetzt im index 12 gespeichert
  } 
  // Ergebnis: frageIndex enthält dieselben Zahlen (0–19), aber in zufälliger Reihenfolge nicht mehr (frageIndex[0] = 0, frageIndex[1] = 1, ...) sondern (frageIndex[0] = 6, frageIndex[1] = 17, ...)
}



//===========ENDLOSSCHLEIFE (LOOP)===========================================================================
void loop() {
  // Prüfen ob sich der Zustand geändert hat – nur dann den neuen Bildschirm zeichnen
  // Verhindert, dass der Bildschirm in jedem Loop-Durchlauf neu gezeichnet wird
  if (quizState != lastState) {
    lastState = quizState;

    switch (quizState) {
      case STATE_MENU:          drawMenu(); break; // Menu Bildschirm zeichnen
      case STATE_START:         drawStart(); break; // Sart Bildschirm zeichnen
      case STATE_QUESTION:      drawQuestion(); break;  // frage Bildschrim zeichnen
      case STATE_ANSWER_SELECT: break; // nur Touch, heit kein Bildschirmwechsel nötig
      case STATE_ANSWER_RESULT: drawResult(); break; // Ergebnis Bildschirm zeichnen
      case STATE_GAMEOVER:      drawGameOver(); break; // Gamever Bildschirm zeichnen
    }
  }

  handleTouch(); // In jedem Loop durchlauf die Touch eingabe prüfen
}

//============ Schwarzen Button mit weißem Rand erzeugen ====================================================
// Ausgefülltes schwarzes Rechteck mit weißem Rand (Standart Button aussehen)
// x,y = koordinaten der oberen linke ecke, w,h = hoehe und breite
void drawButton(int x, int y, int w, int h) {
  tft.fillRect(x, y, w, h, 0x0);
  tft.drawRect(x, y, w, h, 0xFFFF);
}
//=================== MENU SCREEN ===========================================================================
void drawMenu(){
  tft.fillRect(0, 0, 480, 320, COLOR_BG);
  tft.setTextColor(TFT_WHITE);
  tft.setFreeFont();
  //Titel
  // tft.setTextSize(4);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial18pt8b);
  tft.drawString("Quiz", 200, 12);
  //Start-Button
  drawButton(90, 120, 300, 60);
  // tft.setTextSize(3);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial14pt8b);
  tft.drawString("Start Quiz", 170, 134);
  // Infos
  // tft.setTextSize(2);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial10pt8b);
  const char* thema = doc["thema"] | "Quiz"; // Fals es kein Thema exsitiert dann kommt einfach Quiz
  tft.drawString(String("Thema: ") + thema, 130, 201);
  tft.drawString(String("Fragen: ") + String(anzahlFragen), 177, 235);

}
                  
//===================== START SCREEN ========================================================================
void drawStart() {
  tft.fillRect(0, 0, 480, 320, COLOR_BG);
  tft.setTextColor(0xFFFF);
  // tft.setTextSize(4);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial18pt8b);
  tft.drawString("SPIEL BEGINNT", 100, 132);

  delay(1500);
  quizState = STATE_QUESTION;
  
}
//==================== Zeilen Umbruch mit Bindestrich am ende ===============================================
// Gibt einen langen Text in mehreren Zeilen aus – bricht automatisch um, wenn die Pixelbreite überschritten wird 
void drawStringWrapped(String text, int x, int y, int maxWidth, int lineHeight) {
  int start = 0;
  int len = text.length(); // Gesamtlänge des Textes in Zeichen (nicht Pixel!)

  while (start < len) { // Solange noch nicht alle Zeichen ausgegeben wurden
    int cut = start + 1; // Startposition für den nächsten Ausschnitt (mind. 1 Zeichen)
    bool needsHyphen = false; // Wird true, wenn am Zeilenende ein Bindestrich nötig ist
    
    // Schrittweise Zeilen füllen bis die Schrittweise überschritten wird
    while (cut <= len) { // während da zwischen ergebnis kleiner als die zeichenketten länge ist
      String substr = text.substring(start, cut); // Textausschnit von start bis cut
      int w = tft.textWidth(substr);              // Breite des Ausschnitts in Pixel berechnen
      if (w > maxWidth) { // wenn Pixel breite  die maximal pixelbreite überschreitet dann Schleife stoppen | der Rest der Zeichen werden für den nächsten Durchlauf in der nächsten Zeile eingesetzt
        cut--; // Ein Schritt zurückggehen
        needsHyphen = (cut < len); // Text geht weiter -> Bindestrich nötig
        break;
      }
      cut++;  // Noch ein Zeichen mehr testen
    }
    // Sicherheitsfallback: Immer mindestens 1 Zeichen ausgeben (verhindert Endlosschleife)
    if (cut <= start) cut = start + 1;
    
    // aus den gegeben Textausschnitt eine Zeile generieren
    String line = text.substring(start, cut); 
     if (needsHyphen){
      tft.drawString(line + "-", x, y); // Zeile ausgeben mit bindestrich am Ende (in Zeile 214 wird dafür ein Platzhalter gemacht)
     }
     else{
      tft.drawString(line, x, y); // Zeile  normal ausgeben ohne Bindestrich 
     }
    
    y += lineHeight; // Y wert für die Nächste Zeile setzten damit sie unten drunter ausgegeben werden kann (Zeilenabstand)
    start = cut; // machen bei dem Zeichen weiter wo wir aufgehört haben und speichern es in der Variable um den Rest für den nächsten Durchlauf zu bentzten
  }
}

//========================= FRAGEN SCREEEN====================================================================
void drawQuestion(){
  // Hintergrund
  tft.fillRect(0, 0, 480, 320, COLOR_BG);
  // ------------Header-Bereich (schwarze leiste oben)-----------
  tft.fillRect(0, 0, 480, 40, 0x0); // Schwazes Rechteck als  header Hintergrund
  tft.setTextColor(0xFFFF);         // Weißer Text im Header
  // tft.setTextSize(2);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial10pt8b);

  // Aktuelle Fragenummer anzeigen (z.B. "Frage 3/20")
  tft.drawString( "Frage " + String(aktuelleFrage + 1) + "/" + String(anzahlFragen), 10, 12);

  // Thema aus der Json
  const char* thema = doc["thema"] | "Quiz"; // Fals das Thema nicht gefunden ist, wird stattdessen Quiz angezeigt um das Programm nicht abzustürzen
  tft.drawString(String("Thema: ") + thema, 220, 7);

  // --------------- Fragenkasten (schwarzes Rechteck mit weißen Rand) ---------------
  tft.fillRect(10, 50, 460, 90, 0x0);
  tft.drawRect(10, 50, 460, 90, 0xFFFF);

  // Frage und antwort aus gemischten Index  laden
  JsonObject q = doc["fragen"][frageIndex[aktuelleFrage]];
  String frageText = q["frage"].as<const char*>();
  JsonArray a = q["antworten"];

  // Fragetext mit automatischem Zeilenumbruch ausgeben
  // tft.setTextSize(2);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial10pt8b);
  drawStringWrapped(frageText, 20, 60, 440, 25); // x, y, maxWidth, Zeilenhöhe/Zeilenabstand
  // tft.drawString(q["frage"].as<const char*>(), 20, 80);
  
  // -----------Antwort-Buttons------------
  drawButton(10, 150, 220, 75); // Button A
  drawButton(250, 150, 220, 75); // Buton B
  drawButton(10, 240, 220, 75); // Button C
  drawButton(250, 240, 220, 75);  // Button D
  //------------Antwort-Texte---------------
  drawStringWrapped(String("A: ") + a[0].as<const char*>(), 20, 155, 195, 20); // x, y, maxWidth, Zeilenhöhe/Zeilenabstand
  drawStringWrapped(String("B: ") + a[1].as<const char*>(), 260, 155, 195, 20); // x, y, maxWidth, Zeilenhöhe/Zeilenabstand
  drawStringWrapped(String("C: ") + a[2].as<const char*>(), 20, 243, 195, 20); // x, y, maxWidth, Zeilenhöhe/Zeilenabstand
  drawStringWrapped(String("D: ") + a[3].as<const char*>(), 260, 243, 195, 20); // x, y, maxWidth, Zeilenhöhe/Zeilenabstand
}
//==================== GAMEOVER SCREEN ===============================================================================
void drawGameOver(){
  // Hintergrund
  tft.fillRect(0, 0, 480, 320, COLOR_BG);
  tft.setTextColor(0xFFFF);
  //----Titel-----
  // tft.setTextSize(4);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial18pt8b);
  tft.drawString("GAME OVER", 130, 7);
  //Punkte
  // tft.setTextSize(3);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial14pt8b);
  tft.drawString("Punkte: " + String(richtigeAnzahl), 160, 134);
  //-----Richtige Fragen / Gesamt Fragen
  // tft.setTextSize(2);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial10pt8b);
  tft.drawString("Richtige Fragen: " + String(richtigeAnzahl) + "/" + String(anzahlFragen), 140, 191);
  //--------Zurück zum Menü Button
  drawButton(90, 250, 300, 50);
  // tft.setTextSize(2);
  tft.setTextSize(1);
  tft.setFreeFont(&Arial10pt8b);
  tft.drawString("Zurück zum Menü", 155, 261);
}



//================= ANTWORT TEXT    DIE ANTWORT WIEDERGABE FÜR DAS ERGBNIS ======================================

void drawAntwortText(int idx) {
  JsonObject q = doc["fragen"][frageIndex[aktuelleFrage]];
  JsonArray a = q["antworten"];

  int x, y;
  String label = " ";
  switch (idx) {
    case 0: x = 20; label = "A: ";  y = 155; break; // A
    case 1: x = 260; label = "B: "; y = 155; break; // B
    case 2: x = 20; label = "C: ";  y = 243; break; // C
    case 3: x = 260; label = "D: "; y = 243 ; break; // D
    default: return;
  }

  tft.setTextColor(TFT_BLACK);   // schwarzer Text auf gelb/grün/rot
  tft.setTextSize(1);
  tft.setFreeFont(&Arial10pt8b);
  drawStringWrapped(String(label) + a[idx].as<const char*>(),x, y,195,20);
}

//============== ANTWORT-BOX (GELB; GRUEN; ROT) ====================================================================
void drawAntwortBox(int idx, uint16_t color) {
  int x, y;

  switch (idx) {
    case 0: // A
      x = 10;  y = 150;
      break;
    case 1: // B
      x = 250; y = 150;
      break;
    case 2: // C
      x = 10;  y = 240;
      break;
    case 3: // D
      x = 250; y = 240;
      break;
    default:
      return;
  }
  tft.fillRect(x, y, 220, 75, color); // Entschiedene Farbe
  tft.drawRect(x, y, 220, 75, TFT_WHITE); // weißer Rand
  // jetzt wird nur ein roter,greuner, gelber Rechteck angezeigt, wir mussen den Text im Rechteck wiedergeben

  drawAntwortText(idx); // Text wiedergeben
}

//=========== ERGEBNIS ==============================================================================================
void drawResult() {
  JsonObject q = doc["fragen"][frageIndex[aktuelleFrage]];
  richtigeAntwort = q["korrekt"];

  if (gewaehlteAntwort == richtigeAntwort) {
    drawAntwortBox(gewaehlteAntwort, COLOR_GREEN);
    richtigeAnzahl++;
  } else {
    drawAntwortBox(gewaehlteAntwort, COLOR_RED);
    drawAntwortBox(richtigeAntwort, COLOR_GREEN);
  }

  delay(1200);

  aktuelleFrage++;
  gewaehlteAntwort = -1;

  if (aktuelleFrage >= anzahlFragen) {
  quizState = STATE_GAMEOVER;
  }
  else {
  quizState = STATE_QUESTION;
  }

}
//===================== TOUCH LOGIK ==================================================================================
void handleTouch() {
  if (!ts.tirqTouched() || !ts.touched()) return;

  TS_Point p = ts.getPoint();
  int x = map(p.x, 220, 3900, 0, 480);  // Touch-Rohwert (220-3900) -> Pixel X (0-480)
  int y = map(p.y, 3800, 200, 0, 320);  // Touch-Rohwert (3800-200) -> Pixel Y (0-320), gespiegelt damit es von oben nach unten verläuft (wie normal) und nd von unten nach oben
  Serial.print("X: "); Serial.print(p.x);
  Serial.print(" Y: "); Serial.println(p.y);

  delay(200); // Entprellen

  // ================= MENU ==========================================================================================
  if (quizState == STATE_MENU) {
    if (x > 90 && x < 390 && y > 120 && y < 180) {
      quizState = STATE_START;
    }
  }
  // ============== QUESTION =========================================================================================
  if (quizState == STATE_QUESTION) {
    quizState = STATE_ANSWER_SELECT;
  }

    // -------------- ANSWER  SELECT -----------------------
  if (quizState == STATE_ANSWER_SELECT) {
    int antwort = -1;

    if (y > 150 && y < 225) {
      if (x > 10 && x < 230) antwort = 0;       // A
      else if (x > 250 && x < 470) antwort = 1; // B
    }
    else if (y > 240 && y < 315) {
      if (x > 10 && x < 230) antwort = 2;       // C
      else if (x > 250 && x < 470) antwort = 3; // D
    }

    if (antwort != -1) {
      gewaehlteAntwort = antwort;
      drawAntwortBox(antwort, COLOR_YELLOW);
      delay(1000); // Richtige Ergebnis nach 1 Sekunde anzeigen
      quizState = STATE_ANSWER_RESULT;
    }
  }

  // ================= GAME OVER ======================================================================================
  if (quizState == STATE_GAMEOVER) {
    if (x > 90 && x < 390 && y > 250 && y < 300) {
      aktuelleFrage = 0;
      richtigeAnzahl = 0;
      mischeFragen();
      quizState = STATE_MENU;
    }
  }
}




